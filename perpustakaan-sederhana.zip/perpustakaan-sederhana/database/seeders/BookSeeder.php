<?php

namespace Database\Seeders;

use App\Models\Book;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class BookSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Book::create([
            'judul_buku' => 'Mahir bahasa pemograman PHP',
            'nama_penulis' => 'Miftahul Jannah',
            'nama_penerbit' => 'PT Elex Media',
            'tahun_terbit' => '2019',
            'jumlah_halaman' => '200',
        ]);
    }
}
