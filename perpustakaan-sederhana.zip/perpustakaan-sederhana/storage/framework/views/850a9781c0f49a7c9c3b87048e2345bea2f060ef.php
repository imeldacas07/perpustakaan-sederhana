

<?php $__env->startSection('title', 'Data Buku'); ?>

<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('buku.create')); ?>">
  <button class="btn btn-primary">Tambah</button>
</a>
<hr>
<table class="table table-bordered table-secondary">
    <thead>
      <tr>
        <th scope="col">No</th>
        <th scope="col">Judul Buku</th>
        <th scope="col">Nama Penulis</th>
        <th scope="col">Nama Penerbit</th>
        <th scope="col">Tahun Terbit</th>
        <th scope="col">Jumlah Halaman</th>
        <th scope="col">Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th scope="row"><?php echo e($book->id); ?></th>
        <td><?php echo e($book->judul_buku); ?></td>
        <td><?php echo e($book->nama_penulis); ?></td>
        <td><?php echo e($book->nama_penerbit); ?></td>
        <td><?php echo e($book->tahun_terbit); ?></td>
        <td><?php echo e($book->jumlah_halaman); ?></td>
        <td nowrap>
          <a href="<?php echo e(route('buku.edit', $book->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
          <form action="<?php echo e(route('buku.destroy', $book->id)); ?>" method="POST" class="d-inline">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
          </form>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
  </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\perpustakaan-sederhana\resources\views/pages/book/index.blade.php ENDPATH**/ ?>