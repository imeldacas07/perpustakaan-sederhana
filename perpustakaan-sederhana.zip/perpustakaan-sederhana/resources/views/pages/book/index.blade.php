@extends('layouts.app')

@section('title', 'Data Buku')

@section('content')
<a href="{{ route('buku.create') }}">
  <button class="btn btn-primary">Tambah</button>
</a>
<hr>
<table class="table table-bordered table-secondary">
    <thead>
      <tr>
        <th scope="col">No</th>
        <th scope="col">Judul Buku</th>
        <th scope="col">Nama Penulis</th>
        <th scope="col">Nama Penerbit</th>
        <th scope="col">Tahun Terbit</th>
        <th scope="col">Jumlah Halaman</th>
        <th scope="col">Aksi</th>
      </tr>
    </thead>
    <tbody>
      @foreach ($books as $book)
      <tr>
        <th scope="row">{{ $book->id }}</th>
        <td>{{ $book->judul_buku }}</td>
        <td>{{ $book->nama_penulis }}</td>
        <td>{{ $book->nama_penerbit }}</td>
        <td>{{ $book->tahun_terbit }}</td>
        <td>{{ $book->jumlah_halaman }}</td>
        <td nowrap>
          <a href="{{ route('buku.edit', $book->id) }}" class="btn btn-sm btn-warning">Edit</a>
          <form action="{{ route('buku.destroy', $book->id) }}" method="POST" class="d-inline">
            @csrf
            @method('delete')
            <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
          </form>
        </td>
      </tr>
      @endforeach

    </tbody>
  </table>
@endsection