@extends('layouts.app')

@section('title', 'Tambah Buku')

@section('content')
<form action="{{ route('buku.store') }}" method="POST">
    @csrf
    <div class="mb-3">
      <label class="form-label">Judul Buku</label>
      <input type="text" class="form-control @error('judul_buku')
      is-invalid
      @enderror"
      name="judul_buku">
      @error('judul_buku')
        <div class="invalid-feedback">
            {{ $message }}
        </div>
      @enderror
    </div>
    <div class="mb-3">
        <label class="form-label">Nama Penulis</label>
        <input type="text" class="form-control @error('nama_penulis')
        is-invalid
        @enderror"
        name="nama_penulis">
        @error('nama_penulis')
          <div class="invalid-feedback">
              {{ $message }}
          </div>
        @enderror
    </div>
    <div class="mb-3">
        <label class="form-label">Nama Penerbit</label>
        <input type="text" class="form-control @error('nama_penerbit')
        is-invalid
        @enderror"
        name="nama_penerbit">
        @error('nama_penerbit')
          <div class="invalid-feedback">
              {{ $message }}
          </div>
        @enderror
    </div>
    <div class="mb-3">
        <label class="form-label">Tahun Terbit</label>
        <input type="text" class="form-control @error('tahun_terbit')
        is-invalid
        @enderror"
        name="tahun_terbit">
        @error('tahun_terbit')
          <div class="invalid-feedback">
              {{ $message }}
          </div>
        @enderror
    </div>
    <div class="mb-3">
        <label class="form-label">Jumlah Halaman</label>
        <input type="text" class="form-control @error('jumlah_halaman')
        is-invalid
        @enderror"
        name="jumlah_halaman">
        @error('jumlah_halaman')
          <div class="invalid-feedback">
              {{ $message }}
          </div>
        @enderror
    </div>
    <button type="submit" class="btn btn-primary">Tambah Buku</button>
  </form>
@endsection